﻿namespace EczaneOtomasyonu.Stok
{
    partial class YeniUrun
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnEkle = new Button();
            txtAdet = new TextBox();
            label4 = new Label();
            txtUrunAdi = new TextBox();
            label3 = new Label();
            txtBarkod = new TextBox();
            label2 = new Label();
            txtBirimFiyat = new TextBox();
            label1 = new Label();
            btnTemizle = new Button();
            btnİptal = new Button();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            txtUreticiFirma = new TextBox();
            label10 = new Label();
            label11 = new Label();
            txtSonKullanmaTarihi = new TextBox();
            label12 = new Label();
            SuspendLayout();
            // 
            // btnEkle
            // 
            btnEkle.BackColor = Color.SpringGreen;
            btnEkle.FlatAppearance.BorderSize = 0;
            btnEkle.FlatStyle = FlatStyle.Flat;
            btnEkle.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnEkle.Location = new Point(288, 339);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(138, 33);
            btnEkle.TabIndex = 89;
            btnEkle.Text = "Ekle";
            btnEkle.UseVisualStyleBackColor = false;
            btnEkle.Click += btnEkle_Click;
            // 
            // txtAdet
            // 
            txtAdet.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            txtAdet.Location = new Point(26, 202);
            txtAdet.Multiline = true;
            txtAdet.Name = "txtAdet";
            txtAdet.Size = new Size(295, 33);
            txtAdet.TabIndex = 88;
            txtAdet.KeyPress += txtAdet_KeyPress;
            // 
            // label4
            // 
            label4.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(26, 167);
            label4.Name = "label4";
            label4.Size = new Size(139, 32);
            label4.TabIndex = 87;
            label4.Text = "Adet:";
            // 
            // txtUrunAdi
            // 
            txtUrunAdi.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            txtUrunAdi.Location = new Point(26, 126);
            txtUrunAdi.Multiline = true;
            txtUrunAdi.Name = "txtUrunAdi";
            txtUrunAdi.Size = new Size(424, 33);
            txtUrunAdi.TabIndex = 86;
            // 
            // label3
            // 
            label3.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(26, 91);
            label3.Name = "label3";
            label3.Size = new Size(139, 32);
            label3.TabIndex = 85;
            label3.Text = "Ürün Adı:";
            // 
            // txtBarkod
            // 
            txtBarkod.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            txtBarkod.Location = new Point(26, 49);
            txtBarkod.Multiline = true;
            txtBarkod.Name = "txtBarkod";
            txtBarkod.Size = new Size(424, 33);
            txtBarkod.TabIndex = 84;
            // 
            // label2
            // 
            label2.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(26, 14);
            label2.Name = "label2";
            label2.Size = new Size(139, 32);
            label2.TabIndex = 83;
            label2.Text = "Barkod:";
            // 
            // txtBirimFiyat
            // 
            txtBirimFiyat.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            txtBirimFiyat.Location = new Point(384, 205);
            txtBirimFiyat.Multiline = true;
            txtBirimFiyat.Name = "txtBirimFiyat";
            txtBirimFiyat.Size = new Size(295, 33);
            txtBirimFiyat.TabIndex = 91;
            txtBirimFiyat.KeyPress += txtBirimFiyat_KeyPress;
            // 
            // label1
            // 
            label1.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(384, 170);
            label1.Name = "label1";
            label1.Size = new Size(179, 32);
            label1.TabIndex = 90;
            label1.Tag = "";
            label1.Text = "Birim Fiyat:";
            // 
            // btnTemizle
            // 
            btnTemizle.BackColor = Color.Yellow;
            btnTemizle.FlatAppearance.BorderSize = 0;
            btnTemizle.FlatStyle = FlatStyle.Flat;
            btnTemizle.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnTemizle.Location = new Point(145, 339);
            btnTemizle.Name = "btnTemizle";
            btnTemizle.Size = new Size(138, 33);
            btnTemizle.TabIndex = 92;
            btnTemizle.Text = "Temizle";
            btnTemizle.UseVisualStyleBackColor = false;
            btnTemizle.Click += btnTemizle_Click;
            // 
            // btnİptal
            // 
            btnİptal.BackColor = Color.Crimson;
            btnİptal.FlatAppearance.BorderSize = 0;
            btnİptal.FlatStyle = FlatStyle.Flat;
            btnİptal.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnİptal.Location = new Point(431, 339);
            btnİptal.Name = "btnİptal";
            btnİptal.Size = new Size(138, 33);
            btnİptal.TabIndex = 93;
            btnİptal.Text = "İptal";
            btnİptal.UseVisualStyleBackColor = false;
            btnİptal.Click += btnİptal_Click;
            // 
            // label5
            // 
            label5.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.Red;
            label5.Location = new Point(451, 49);
            label5.Name = "label5";
            label5.Size = new Size(24, 33);
            label5.TabIndex = 94;
            label5.Text = "*";
            // 
            // label6
            // 
            label6.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.Red;
            label6.Location = new Point(451, 126);
            label6.Name = "label6";
            label6.Size = new Size(24, 33);
            label6.TabIndex = 95;
            label6.Text = "*";
            // 
            // label7
            // 
            label7.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.Red;
            label7.Location = new Point(321, 202);
            label7.Name = "label7";
            label7.Size = new Size(24, 33);
            label7.TabIndex = 96;
            label7.Text = "*";
            // 
            // label8
            // 
            label8.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor = Color.Red;
            label8.Location = new Point(679, 205);
            label8.Name = "label8";
            label8.Size = new Size(24, 33);
            label8.TabIndex = 97;
            label8.Text = "*";
            // 
            // label9
            // 
            label9.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor = Color.Red;
            label9.Location = new Point(321, 280);
            label9.Name = "label9";
            label9.Size = new Size(24, 33);
            label9.TabIndex = 100;
            label9.Text = "*";
            // 
            // txtUreticiFirma
            // 
            txtUreticiFirma.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            txtUreticiFirma.Location = new Point(26, 280);
            txtUreticiFirma.Multiline = true;
            txtUreticiFirma.Name = "txtUreticiFirma";
            txtUreticiFirma.Size = new Size(295, 33);
            txtUreticiFirma.TabIndex = 99;
            // 
            // label10
            // 
            label10.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            label10.Location = new Point(26, 245);
            label10.Name = "label10";
            label10.Size = new Size(179, 32);
            label10.TabIndex = 98;
            label10.Tag = "";
            label10.Text = "Üretici Firma:";
            // 
            // label11
            // 
            label11.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            label11.ForeColor = Color.Red;
            label11.Location = new Point(679, 283);
            label11.Name = "label11";
            label11.Size = new Size(24, 33);
            label11.TabIndex = 103;
            label11.Text = "*";
            // 
            // txtSonKullanmaTarihi
            // 
            txtSonKullanmaTarihi.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            txtSonKullanmaTarihi.Location = new Point(384, 283);
            txtSonKullanmaTarihi.Multiline = true;
            txtSonKullanmaTarihi.Name = "txtSonKullanmaTarihi";
            txtSonKullanmaTarihi.Size = new Size(295, 33);
            txtSonKullanmaTarihi.TabIndex = 102;
            // 
            // label12
            // 
            label12.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            label12.Location = new Point(384, 248);
            label12.Name = "label12";
            label12.Size = new Size(264, 32);
            label12.TabIndex = 101;
            label12.Tag = "";
            label12.Text = "Son Kullanma Tarihi:";
            // 
            // YeniUrun
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(737, 386);
            Controls.Add(label11);
            Controls.Add(txtSonKullanmaTarihi);
            Controls.Add(label12);
            Controls.Add(label9);
            Controls.Add(txtUreticiFirma);
            Controls.Add(label10);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(btnİptal);
            Controls.Add(btnTemizle);
            Controls.Add(txtBirimFiyat);
            Controls.Add(label1);
            Controls.Add(btnEkle);
            Controls.Add(txtAdet);
            Controls.Add(label4);
            Controls.Add(txtUrunAdi);
            Controls.Add(label3);
            Controls.Add(txtBarkod);
            Controls.Add(label2);
            Name = "YeniUrun";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "YeniUrun";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnEkle;
        private TextBox txtAdet;
        private Label label4;
        private TextBox txtUrunAdi;
        private Label label3;
        private TextBox txtBarkod;
        private Label label2;
        private TextBox txtBirimFiyat;
        private Label label1;
        private Button btnTemizle;
        private Button btnİptal;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private TextBox txtUreticiFirma;
        private Label label10;
        private Label label11;
        private TextBox txtSonKullanmaTarihi;
        private Label label12;
    }
}